from keras import models
from keras import layers
import tensorflow as tf
import numpy as np

#设置伪随机数
np.random.seed(6)

class SumTree(object):
    data_pointer = 0
    def __init__(self,capacity):                   #done
        self.capacity = capacity
        # 构建SumTree
        self.tree = np.zeros(2 * capacity - 1)
        # 用于存储transition
        self.data = np.zeros(capacity,dtype = object)


    # 函数本身data存储transition，p通过调用self.update()进行存储
    def add(self,p,data):                       #done
        # SumTree的叶节点索引
        tree_idx = self.data_pointer + self.capacity - 1
        # data表示transition，存储在self.data中
        self.data[self.data_pointer] = data
        # 更新self.tree
        self.update(tree_idx , p)

        self.data_pointer += 1
        if self.data_pointer >= self.capacity:          # 避免超出索引值
            self.data_pointer = 0


    # 更新tree中p值
    def update(self, tree_idx, p):                # done
        change = p - self.tree[tree_idx]
        self.tree[tree_idx] = p

        while tree_idx != 0:
            tree_idx = (tree_idx - 1) // 2
            self.tree[tree_idx] += change


    # 获取叶节点
    def get_leaf(self,v):                       # done
        parent_idx = 0
        while True:
            cl_idx = 2 * parent_idx + 1
            cr_idx = cl_idx + 1
            if cl_idx >= len(self.tree):
                leaf_idx = parent_idx
                break
            else:
                if v <= self.tree[cl_idx]:
                    parent_idx = cl_idx
                else:
                    v -= self.tree[cl_idx]
                    parent_idx = cr_idx

        data_idx = leaf_idx - self.capacity + 1
        # 返回对应叶节点的索引、叶节点的p值、对应的transition
        return leaf_idx,self.tree[leaf_idx],self.data[data_idx]



    def total_p(self):                          # done
        # 返回根节点的p值
        return self.tree[0]




class Memory(object):
    epsilon = 0.01
    alpha = 0.6
    beta = 0.3
    beta_increment_per_sampling = 0.001
    abs_err_upper = 1

    def __init__(self,capacity):                        # done
        # 建立SumTree
        self.tree = SumTree(capacity)


    def store(self,transition):                         # done
        # 用于存储添加p值、transition
        max_p = np.max(self.tree.tree[-self.tree.capacity:])
        if max_p == 0:
            max_p = self.abs_err_upper
        self.tree.add(max_p,transition)


    def sample(self,n):                                # done
        # 根据传入的n值进行抽样
        b_idx, b_memory, ISWeights = np.empty((n,),dtype = np.int32), \
                                     np.empty((n,self.tree.data[0].size)), \
                                     np.empty((n,1))
        # 分成n个区间
        pri_seg = self.tree.total_p() / n
        # max_beta = 1
        self.beta = np.min([1,self.beta + self.beta_increment_per_sampling])
        min_pro = np.min(self.tree.tree[-self.tree.capacity:]) / self.tree.total_p()

        for i in range(n):
            a,b = pri_seg * i,pri_seg * (i+1)
            v = np.random.uniform(a,b)
            idx, p, data = self.tree.get_leaf(v)
            prob = p / self.tree.total_p()
            ISWeights[i,0] = np.power(prob / (min_pro + 0.00001), -self.beta)
            b_idx[i], b_memory[i,:] = idx, data
        return b_idx, b_memory, ISWeights


    def batch_update(self, tree_idx, abs_errors):                    # done
        abs_errors += self.epsilon
        clipped_errors = np.minimum(self.abs_err_upper,abs_errors)
        ps = np.power(clipped_errors, self.alpha)
        for ti, p in zip(tree_idx, ps):
            self.tree.update(ti, p)




class DQNPrioritizedReplay:
    def __init__(self,
                 n_actions,
                 n_features = 4,
                 learning_rate = 0.005,
                 reward_decay = 0.9,
                 e_greedy = 0.9,
                 replace_target_alter = 100,
                 memory_size = 1000,
                 batch_size = 32,
                 greedy_increment = 0.3,
                 ):
        self.n_actions = n_actions
        self.n_features = n_features
        self.gamma = reward_decay
        self.epsilon_max = e_greedy
        self.replace_target_alter = replace_target_alter
        self.memory_size = memory_size
        self.batch_size = batch_size
        self.greedy_increment = greedy_increment
        self.greedy = 0 if greedy_increment is not None else self.epsilon_max

        self.learn_step_counter = 0
        self.memory = Memory(capacity=self.memory_size)
        self.built_network()
        self.cost_hit = []
        self.cost_reward = []


    def change_params(self):
        self.model2.get_layer('D2_1_Params').set_weights(self.model1.get_layer('D1_1_Params').get_weights())
        # self.model2.get_layer('D2_2_Params').set_weights(self.model1.get_layer('D1_2_Params').get_weights())
        self.model2.get_layer('D2_3_Params').set_weights(self.model1.get_layer('D1_3_Params').get_weights())


    def built_network(self):
        # ---------------------------------------built_predict_net---------------------------------------
        self.model1 = models.Sequential()
        self.model1.add(layers.Dense(10,activation='relu',input_shape=(4,),kernel_initializer='random_uniform',name='D1_1_Params'))
        # self.model1.add(layers.Dense(6,activation='relu',kernel_initializer='random_uniform',name='D1_2_Params'))
        self.model1.add(layers.Dense(4,kernel_initializer='random_uniform',name='D1_3_Params'))
        self.model1.summary()

        # ---------------------------------------built_target_net--------------------------------------
        self.model2 = models.Sequential()
        self.model2.add(layers.Dense(10, activation='relu', input_shape=(4,), kernel_initializer='random_uniform',
                                     name='D2_1_Params'))
        # self.model2.add(layers.Dense(6, activation='relu', kernel_initializer='random_uniform', name='D2_2_Params'))
        self.model2.add(layers.Dense(4,  kernel_initializer='random_uniform', name='D2_3_Params'))

    # 每进行一次抽样学习，刷新损失函数与self.model1的重新编译
    def reset_loss_function(self,ISWeights):
        def local_loss(y_actural,y_predict):
            return tf.math.reduce_mean(ISWeights * tf.math.squared_difference(y_actural,y_predict))

        self.model1.compile(loss=local_loss,
                            optimizer='adam',
                            metrics=['acc'])




    def store_transition(self, s, a, r, s_):                        # done
        transition = np.hstack((s, [a,r], s_))
        self.memory.store(transition)


    def choose_action(self,observation):                            # done
        observation = observation.reshape(1,4)
        if np.random.uniform() < self.greedy:
            action = np.argmax(self.model1.predict(observation))
            print(self.model1.predict(observation))
        else:
            action = np.random.randint(0,self.n_actions)
        return action


    def learn(self):
        if self.learn_step_counter % self.replace_target_alter == 0:
            self.change_params()
            print("\ntarget_params_replaced\n")

        tree_idx, batch_memory, ISWeights = self.memory.sample(self.batch_size)
        # 重新编译神经网络
        self.reset_loss_function(ISWeights)

        batch_memory_s = batch_memory[:,:self.n_features]
        batch_memory_s_ = batch_memory[:,-self.n_features:]
        q_next = self.model2.predict(batch_memory_s_)
        q_eval = self.model1.predict(batch_memory_s)

        q_target = q_eval.copy()

        batch_index = np.arange(self.batch_size, dtype = np.int32)
        eval_act_index = batch_memory[:, self.n_features].astype(int)
        reward = batch_memory[:, self.n_features + 1]

        # 用于debug检测抽样是否含有奖励为10
        c = np.array(np.where(reward == 10))
        if c.size != 0:
            self.cost_reward.append(len(c[0]) / self.batch_size)
        else:
            self.cost_reward.append(0)

        q_target[batch_index,eval_act_index] = reward + self.gamma * np.max(q_next,axis=1)

        history = self.model1.fit(batch_memory_s,
                                  q_target,
                                  epochs=500,
                                  batch_size=32,
                                  verbose=0)
        # 求解abs_errors
        self.abs_errors = tf.math.reduce_sum(tf.abs(q_target - q_eval),axis=1)
        # 更新SumTree
        self.memory.batch_update(tree_idx, self.abs_errors)
        # 更新greed，越大表示拥有越小的随机选择
        self.greedy = self.greedy + self.greedy_increment if self.greedy < self.epsilon_max else self.epsilon_max
        # 记录Loss值
        self.cost_hit.append(history.history['loss'])

        self.learn_step_counter += 1


    # 用于返回每次抽样时正奖赏占总抽样数的比例
    def reward_rate(self):
        self.cost_reward = np.array(self.cost_reward)
        length = len(self.cost_reward)
        epoch = range(0,length)
        self.cost_reward = self.cost_reward[epoch]
        return self.cost_reward, epoch

    # 用于返回损失值
    def loss_value(self):
        self.loss = np.array(self.cost_hit)
        a, b = self.loss.shape
        self.loss = self.loss.reshape(a*b, )
        length = len(self.loss)
        epoch = range(0,length,1000)
        self.loss = self.loss[epoch]
        return self.loss, epoch